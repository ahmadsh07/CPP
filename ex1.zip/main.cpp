// תעודת זהות: 212478994
#include <iostream>
#include <fstream>
#include "Obfuscator.h"
#include "LineObfuscator.h"
#include "VarObfuscator.h"
#include "CommentObfuscator.h"
#include <time.h>
#include <time.h>

using namespace std;
int main(){
    srand(time(NULL));
    Obfuscator* obfs[3];
    obfs[0] = new VarObfuscator();
    obfs[1] = new LineObfuscator();
    obfs[2] = new CommentObfuscator();
    obfs[0]->obfuscate("/Users/ahmadshamasnah/CLionProjects/Exs/code.txt");
    for(int i = 1; i < 3; i++)
        obfs[i]->obfuscate(obfs[i-1]->OUT);



    return 0;
}
