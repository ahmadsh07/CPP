// תעודת זהות: 212478994
//This class is inherited from Obfuscator

#ifndef EXS_COMMENTOBFUSCATOR_H
#define EXS_COMMENTOBFUSCATOR_H
#include "Obfuscator.h"
class CommentObfuscator: public Obfuscator {
    void obfuscate(string filename);
};
#endif
