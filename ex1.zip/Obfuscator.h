// תעודת זהות: 212478994

#include <string>
#ifndef EXS_OBFUSCATOR_H
#define EXS_OBFUSCATOR_H
using namespace std;
class Obfuscator{
protected:
   int FILE_LENGTH=0;
public:
    virtual void obfuscate(string fileName) = 0;
    const string OUT = "newCode.c";
    string generateRandomVar();
    string* parseFile(string filename);
    void writeToFile(string* codeArray);
};
#endif
