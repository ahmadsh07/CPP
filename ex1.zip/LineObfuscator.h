// תעודת זהות: 212478994
//This class is inherited from Obfuscator

#ifndef EXS_LINEOBFUSCATOR_H
#define EXS_LINEOBFUSCATOR_H
#include "Obfuscator.h"
class LineObfuscator : public Obfuscator{
    void obfuscate(string fileName);
};
#endif
