// תעודת זהות: 212478994
//This class is inherited from Obfuscator

#include "LineObfuscator.h"
#include <string>
#include "Obfuscator.h"

void LineObfuscator::obfuscate(string fileName) {
    string* codeArray=parseFile(fileName);
    int i=0;
    int main=0;
    int end=0;
    string randVar=Obfuscator::generateRandomVar();
    string newLine="\t"+randVar+" = "+ to_string(rand()%9999)+" + " + to_string(rand()%9999)+";";
     string newVar="\t int "+randVar+";";

    while(i<FILE_LENGTH){
        if(codeArray[i].find("main()")!=string::npos){
            main=i;
            codeArray[i]+="\n"+newVar;
        }
        if(codeArray[i].find("}")!=string::npos)
            end=i;
        i++;
    }

    int randLine=rand()%(end-main-2)+(main+2);
    codeArray[randLine]+="\n"+newLine;

    writeToFile(codeArray);
}
