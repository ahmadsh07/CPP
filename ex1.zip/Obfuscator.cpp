// תעודת זהות: 212478994
#include <iostream>
#include "Obfuscator.h"
#include <fstream>
using namespace std;
    string Obfuscator::generateRandomVar(){
        string chars[4];

        string str="";
        int len=rand()%9+3;
        int Num;
        for(int i=0;i<len;i++){
            chars[0]=rand()%25+'A';
            chars[1]=rand()%25+'a';
            chars[2]='_';
            chars[3]=rand()%9+'0';
            if(i==0){
                Num=rand()%3;
                str+=chars[Num];
            }
            Num=rand()%4;
            str+=chars[Num];
        }

        return str;
    }
    string* Obfuscator::parseFile(string filename) {
        string line;
        ifstream codetest;
       codetest.open(filename);
       while(getline(codetest,line)) FILE_LENGTH++;
        codetest.close();
        codetest.open(filename);
       string *codeArray=new string[FILE_LENGTH];
       int i=0;
       while(getline(codetest,line)){
           codeArray[i]=line;
           i++;
       }
       return codeArray;

        }
    void Obfuscator::writeToFile(string *codeArray) {
        ofstream codetest;
        codetest.open( OUT);
            int i=0;
        while(i<FILE_LENGTH){
            codetest << codeArray[i]<<endl;
            i++;
        }
        codetest.close();
    }

class VarObfuscator : public Obfuscator {
    void obfuscate(string fileName) {

    }
};
class CommentObfuscator : public Obfuscator {
    void obfuscate(string fileName) {

    }
};
