// תעודת זהות: 212478994
//This class is inherited from Obfuscator

#include "VarObfuscator.h"


void VarObfuscator::obfuscate(string filename) {
    string* codeArray= parseFile(filename);

    int main=0;
    int i=0;
    string varArray[20];
    int var=0;
    while(i<FILE_LENGTH){
        if(codeArray[i].find("main()")!=string::npos){
            main=i;
            break;
        }
        i++;
    }
    i=main;
    while(i<FILE_LENGTH&&var<20){
        if(codeArray[i].find("int ")!=string::npos){
           for(int j=codeArray[i].find("int ")+4;j<codeArray[i].length();j++){
               if(codeArray[i].at(j)=='='||codeArray[i].at(j)==';') break;
               varArray[var]+=codeArray[i].at(j);
           }
            var++;
        }
        i++;
    }

    string randVar=varArray[rand()%var];
    string newRandVar=generateRandomVar();
    i=0;
    while(i<FILE_LENGTH){
        if(codeArray[i].find(randVar)!=string::npos){
            codeArray[i]=codeArray[i].replace(codeArray[i].find(randVar),randVar.length(),newRandVar);
        }
        i++;
    }

    writeToFile(codeArray);
}