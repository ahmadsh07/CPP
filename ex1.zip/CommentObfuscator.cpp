// תעודת זהות: 212478994
//This class is inherited from Obfuscator

#include "CommentObfuscator.h"

void CommentObfuscator::obfuscate(string filename) {
    string* codeArray= parseFile(filename);
    string comment[]={"//find even number","//check if even number","//find odd number","//check if odd number"
    ,"//find max","//find min"};
    int i=0;
    while(i<FILE_LENGTH){
     if(codeArray[i].find("//")!=string::npos)
         codeArray[i]=codeArray[i].substr(0,codeArray[i].find("//"));
        i++;
    }

    i=0;
    while(i<7){
        codeArray[rand()%FILE_LENGTH]+="\n"+comment[rand()%6];
        i++;
    }

    writeToFile(codeArray);

}
