// תעודת זהות: 212478994
//This class is inherited from Obfuscator
#ifndef EXS_VAROBFUSCATOR_H
#define EXS_VAROBFUSCATOR_H
#include "Obfuscator.h"
class VarObfuscator : public Obfuscator{
    void obfuscate(string fileName);
};
#endif
